export interface IAddress {
  flat : string;
  street : string;
  landmark : string;
  city : string;
  state : string;
  country : string;
  pin : string;
  mobile : string;
}
