import { Action, createReducer, on } from '@ngrx/store';
import {IProduct} from "../../products/models/IProduct";
import * as orderActions from '../actions/order.actions';
import {IOrder} from "../models/IOrder";

export const orderFeatureKey = 'order';

export interface State {
  cartItems:IProduct[],
  loading : boolean,
  errorMessage : string,
  orders : IOrder[]
}

export const initialState: State = {
  cartItems:[],
  loading : false,
  errorMessage : '',
  orders : [] as IOrder[]
};

export const reducer = createReducer(
  initialState,
  // Add to Cart
  on(orderActions.addToCart, (state, {product, selectedQty}) => {
    let selectedProduct = {...product , qty : selectedQty};
    let existingProduct = state.cartItems.find((cartItem) => cartItem._id === product._id);
    if(existingProduct){
      return state;
    }
    return {
      ...state,
      cartItems : [...state.cartItems , selectedProduct]
    }
  }),
  // Increase Cart Item Qty
  on(orderActions.incrCartItemQty, (state , {product}) => {
    let updatedCartItems = state.cartItems.map((cartItem) => {
      if(cartItem._id === product._id){
         return {
           ...cartItem,
           qty : cartItem.qty + 1
         }
      }
      return cartItem;
    });
    return {
      ...state,
      cartItems : [...updatedCartItems]
    }
  }),
  // Decrease Cart Item Qty
  on(orderActions.decrCartItemQty, (state , {product}) => {
    let updatedCartItems = state.cartItems.map((cartItem) => {
      if(cartItem._id === product._id){
        return {
          ...cartItem,
          qty : (cartItem.qty - 1 > 0) ? cartItem.qty - 1 : 1
        }
      }
      return cartItem;
    });
    return {
      ...state,
      cartItems : [...updatedCartItems]
    }
  }),
  // Delete a Cart Item
  on(orderActions.deleteCartItem, (state , {product}) => {
    let remainingCartItems = state.cartItems.filter((cartItem) => {
      return cartItem._id !== product._id;
    });
    return {
      ...state,
      cartItems : [...remainingCartItems]
    }
  }),
  on(orderActions.sendCartItems, (state, {cartItems}) => {
    return {
      ...state,
      loading : true
    }
  }),
  on(orderActions.sendCartItemsSuccess, (state, {msg}) => {
    return {
      ...state,
      loading : false
    }
  }),
  on(orderActions.sendCartItemsFailure, (state, {error}) => {
    return {
      ...state,
      loading : false,
      errorMessage : error
    }
  }),
  // get all the orders
  on(orderActions.getAllOrders, (state) => {
    return {
      ...state,
      loading : true
    }
  }),
  on(orderActions.getAllOrdersSuccess, (state,{orders}) => {
    return {
      ...state,
      loading : false,
      orders : orders
    }
  }),
  on(orderActions.getAllOrdersFailure, (state, {error}) => {
    return {
      ...state,
      loading : false,
      errorMessage : error
    }
  }),
);

